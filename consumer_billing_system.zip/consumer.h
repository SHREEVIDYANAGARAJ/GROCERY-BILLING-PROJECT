#ifndef CONSUMER_H
#define CONSUMER_H

void addConsumer();
void displayConsumerDetails(char phoneNumber[]);

#endif
