#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "billing.h"
#include "consumer.h"

// Item prices and units
float prices[] = {220, 195, 65, 75, 45, 30, 200, 27, 100, 25};
char *items[] = {"Toor Dal(1 kg)       ", "Masoor Dal(1 kg)  ", "Rice(1 kg)        ", "Mustard(200g)   ", "Turmeric(100g)    ", 
                 "Jeera(100g)       ", "Tamarind(1 kg)    ", "Methi(100g)       ", "Garam Masala(100g)", "Salt(1 kg)        "};

void generateBill() {
    // Item prices and units
    float prices[] = {220, 195, 65, 75, 45, 30, 200, 27, 100, 25};
    char *items[] = {"Toor Dal(1 kg)       ", "Masoor Dal(1 kg)  ", "Rice(1 kg)        ", "Mustard(200g)   ", "Turmeric(100g)    ", 
                     "Jeera(100g)       ", "Tamarind(1 kg)    ", "Methi(100g)       ", "Garam Masala(100g)", "Salt(1 kg)        "};

    char choice;
    int quantities[10] = {0};  // Initialize quantities for each item to 0
    float totalCost = 0;

    printf("Menu:\n");
    printf("1 - Toor Dal(1 kg)            - Rs 220\n");
    printf("2 - Masoor Dal(1 kg)          - Rs 195\n");
    printf("3 - Rice(1 kg)                - Rs 65\n");
    printf("4 - Mustard(200g)             - Rs 75\n");
    printf("5 - Turmeric(100 g)           - Rs 45\n");
    printf("6 - Jeera(100 g)               - Rs 30\n");
    printf("7 - Tamarind(1 kg)            - Rs 200\n");
    printf("8 - Methi(100g)               - Rs 27\n");
    printf("9 - Garam Masala(100g)        - Rs 100\n");
    printf("0 - Salt(1 kg)                - Rs 25\n");
    printf("B/b - Generate bill\n");
    printf("\n");
    printf("\n");
   
   

    while (1) {
        printf("Enter your choice: ");
        scanf(" %c", &choice);

        switch (choice) {
            case '1':
            case '2':
            case '3':
            case '4':
            case '7':
            case '9':
            case '0':
                printf("Enter quantity: ");
                int quantity;
                scanf("%d", &quantity);
                int index = choice - '1';
                if (choice == '0') index = 9;  // Adjust index for '0' choice
                quantities[index] += quantity;  // Add the quantity to the existing quantity for the item
                float cost = prices[index] * quantity;
                totalCost += cost;
                printf("Added %s x %d to the bill. Cost: Rs %.2f\n", items[index], quantity, cost);
                break;
            case '5':
            case '6':
            case '8':
                printf("Enter quantity: ");
                scanf("%d", &quantity);
                index = choice - '1';
                quantities[index] += quantity;  // Add the quantity to the existing quantity for the item
                cost = prices[index] * quantity;
                totalCost += cost;
                printf("Added %s x %d to the bill. Cost: Rs %.2f\n", items[index], quantity, cost);
                break;
            case 'B':
            case 'b':
                printf("enter phone number: ");
                int pn;

                
                scanf("%d", &pn);
                printf("Generating bill...\n");
                printf("Item ID\tItem Name\t\tQuantity\tCost\n");
                for (int i = 0; i < 10; i++) {
                    if (quantities[i] > 0) {
                        printf("%d\t%s\t\t%d\t\tRs %.2f\n", i + 1, items[i], quantities[i], prices[i] * quantities[i]);
                    }
                }
                printf("Total Cost: Rs %.2f\n", totalCost);
                printf("Cost including GST: Rs %.2f\n", (totalCost + (0.18 * totalCost)));
                printf("phone number: %d",pn);
                printf("\n");
                printf("Thank You\n");
                return;
            default:
                printf("Invalid choice. Please enter a number shown in the menu or 'B' to generate bill.\n");
                break;
        }
    }
}
