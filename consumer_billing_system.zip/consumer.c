#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "consumer.h"

#define MAX_CONSUMERS 100

// Storing consumer data
char names[MAX_CONSUMERS][50];
char PHNO[MAX_CONSUMERS][15];
char CID[MAX_CONSUMERS][10];

int numConsumers = 0;

void addConsumer() {
    char name[50];
    char phone[15];

    printf("Enter name: ");
    scanf("%s", name);
    printf("Enter phone number: ");
    scanf("%s", phone);

    for (int i = 0; i < numConsumers; i++) {
        if (strcmp(PHNO[i], phone) == 0) {
            printf("You are already registered. You may go for billing.\n");
            return;
        }
    }

    if (numConsumers >= MAX_CONSUMERS) {
        printf("Maximum number of consumers reached.\n");
        return;
    }

    strcpy(names[numConsumers], name);
    strcpy(PHNO[numConsumers], phone);

    // Generate a random consumer ID (for demonstration purposes)
    sprintf(CID[numConsumers], "%05d", rand() % 100000);

    numConsumers++;

    printf("Consumer added successfully.\n");
}

void displayConsumerDetails(char phoneNumber[]) {
    int i;
    int found = 0;

    for (i = 0; i < numConsumers; i++) {
        if (strcmp(PHNO[i], phoneNumber) == 0) {
            printf("\nName: %s\n", names[i]);
            printf("Phone Number: %s\n", PHNO[i]);
            printf("Consumer ID: %s\n", CID[i]);
            found = 1;
            break;
        }
    }

    if (!found) {
        printf("Consumer not found.\n");
    }
}

