#ifndef BILLING_H
#define BILLING_H

void generateBill();

#endif
