#include <stdio.h>
#include "consumer.h"
#include "billing.h"

int main() {
    int choice;
    char phoneNumber[15];

    do {
        printf("\n1. Add Consumer\n");
        printf("2. Display Consumer Details\n");
        printf("3. Generate Bill\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                addConsumer();
                break;
            case 2:
                printf("Enter phone number of the consumer: ");
                scanf("%s", phoneNumber);
                displayConsumerDetails(phoneNumber);
                break;
            case 3:
                generateBill();
                break;
            case 4:
                printf("Exiting program.\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 4);

    return 0;
}

